package com.sample.test.listeners;


public interface ClickListener {

    void onclickListener();
}
