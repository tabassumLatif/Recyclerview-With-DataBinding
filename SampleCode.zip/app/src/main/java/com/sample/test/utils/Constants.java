package com.sample.test.utils;

public class Constants {

    String URL = "";
}
